const mongoose = require("mongoose");
mongoose.connect(
  `mongodb+srv://ayush1803:ayush1803@cluster0.d4m58.mongodb.net/?retryWrites=true&w=majority`
);
